from kfp.v2.dsl import pipeline
from components.train_component import train_diabetes_component

@pipeline(
    name="diabetes-training-pipeline",
    pipeline_root="gs://gcp-ml-project-sri-ml-artifacts/pipeline-root",
)
def diabetes_pipeline(
    project: str,
    region: str,
    data_path: str,
    model_dir: str,
):
    train_diabetes_component(
        project=project,
        region=region,
        data_path=data_path,
        model_dir=model_dir,
    )
