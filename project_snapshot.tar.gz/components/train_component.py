from google_cloud_pipeline_components.v1.custom_job import CustomTrainingJobOp
def train_diabetes_component(
    data_path: str,
    model_dir: str,
    project: str,
    region: str,
) -> str:
    """
    Pipeline step that launches the diabetes training job.
    """

    CustomTrainingJobOp(
        project=project,
        location=region,
        display_name="diabetes-training-job",
        worker_pool_specs=[
            {
                "machine_spec": {
                    "machine_type": "n1-standard-4",
                },
                "replica_count": 1,
                "python_package_spec": {
                    "executor_image_uri":
                        "us-docker.pkg.dev/vertex-ai/training/sklearn-cpu.1-0:latest",
                    "package_uris": [
                        "gs://gcp-ml-project-sri-ml-artifacts/packages/train_diabetes.tar.gz"
                    ],
                    # MUST match folder/module structure
                    "python_module": "train_pkg.train",
                    "args": [
                        "--data_path", data_path,
                        "--model_dir", model_dir,
                    ],
                },
            }
        ],
    )

    # Expose model location to pipeline
    return model_dir
