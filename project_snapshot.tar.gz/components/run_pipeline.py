from google.cloud import aiplatform

PROJECT_ID = "gcp-ml-project-sri"
REGION = "us-central1"
PIPELINE_SPEC_PATH = "C:/sridhar/MLProjects/gcp-setup-latest/code/diabetes_pipeline.json"
PIPELINE_ROOT = "gs://gcp-ml-project-sri-ml-artifacts/pipeline-root"

def run():
    aiplatform.init(
        project=PROJECT_ID,
        location=REGION,
    )

    job = aiplatform.PipelineJob(
    display_name="diabetes-training-pipeline",
    template_path="diabetes_pipeline.json",
    pipeline_root="gs://gcp-ml-project-sri-ml-artifacts/pipeline-root",
    parameter_values={
        "data_path": "gs://gcp-ml-project-sri-ml-artifacts/data/diabetes.csv",
        "model_dir": "gs://gcp-ml-project-sri-ml-artifacts/models/diabetes",  # ✅ REQUIRED
        "project": "gcp-ml-project-sri",
        "region": "us-central1",
    },
)

    job.run(sync=True)

if __name__ == "__main__":
    run()
