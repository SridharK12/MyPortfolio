import sys
print(sys.path)
from kfp import compiler
from pipelines_diabetes.diabetes_pipeline import diabetes_pipeline


compiler.Compiler().compile(
    pipeline_func=diabetes_pipeline,
    package_path="diabetes_pipeline.json",
)
