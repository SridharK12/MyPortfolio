import argparse
import os

# =========================================================
# 🔧 HARD-CODED PATHS (DEBUG MODE)
# =========================================================
HARDCODED_DATA_PATH = "gs://gcp-ml-project-sri-ml-artifacts/data/diabetes.csv"
HARDCODED_MODEL_DIR = "gs://gcp-ml-project-sri-ml-artifacts/models/diabetes/v1"

def main():
    parser = argparse.ArgumentParser()

    # Keep args optional for debug
    parser.add_argument("--data_path", type=str, required=False)
    parser.add_argument("--model_dir", type=str, required=False)

    args = parser.parse_args()

    # =====================================================
    # ✅ Use hard-coded values if args not passed
    # =====================================================
    data_path = args.data_path or HARDCODED_DATA_PATH
    model_dir = args.model_dir or HARDCODED_MODEL_DIR

    print(f"Using data_path  : {data_path}")
    print(f"Using model_dir  : {model_dir}")

    # -----------------------------------------------------
    # Example training logic
    # -----------------------------------------------------
    import pandas as pd
    from sklearn.linear_model import LogisticRegression
    import joblib

    df = pd.read_csv(data_path)

    X = df.drop("Outcome", axis=1)
    y = df["Outcome"]

    model = LogisticRegression(max_iter=1000)
    model.fit(X, y)

    os.makedirs(model_dir.replace("gs://", "/gcs/"), exist_ok=True)

    joblib.dump(model, "/gcs/" + model_dir.replace("gs://", "") + "/model.joblib")

    print("✅ Model training completed successfully")

if __name__ == "__main__":
    main()
