package com.example.customerapi.controller;

import com.example.customerapi.dto.CustomerDetailsWithStatusResponse;
import com.example.customerapi.entity.Customer;
import com.example.customerapi.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {
    
    @Autowired
    private CustomerService customerService;
    
    @GetMapping
    public List<Customer> getAllCustomers() {
        return customerService.getAllCustomers();
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Customer> getCustomerById(@PathVariable Long id) {
        return customerService.getCustomerById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    private static final Logger log = LoggerFactory.getLogger(CustomerController.class);
    // ----------------------------------------------------------
    // NEW ENDPOINT: Customer + status
    // GET /api/customers/{id}/with-status
    // ----------------------------------------------------------
    @GetMapping("/{id}/with-status")
    public ResponseEntity<CustomerDetailsWithStatusResponse> getCustomerWithStatus(@PathVariable Long id) {
        try {
        	log.info("Before calling customer status for Customer Id {}", id);
        	CustomerDetailsWithStatusResponse response =
                    customerService.getCustomerDetailsWithStatus(id);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            // thrown when customer is not found
            return ResponseEntity.notFound().build();
        }
    }
    // ----------------------------------------------------------
    
    @PostMapping
    public Customer createCustomer(@RequestBody Customer customer) {
        return customerService.createCustomer(customer);
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<Customer> updateCustomer(@PathVariable Long id, @RequestBody Customer customer) {
        try {
            return ResponseEntity.ok(customerService.updateCustomer(id, customer));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable Long id) {
        customerService.deleteCustomer(id);
        return ResponseEntity.noContent().build();
    }
}
