package com.example.customerapi.service;

import com.example.customerapi.dto.CustomerDetailsWithStatusResponse;
import com.example.customerapi.dto.CustomerStatusResponse;
import com.example.customerapi.entity.Customer;
import com.example.customerapi.repository.CustomerRepository;
import com.example.customerapi.mapper.CustomerMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private RestTemplate restTemplate;   // <-- DIRECT API CALL WILL USE THIS

    private static final String STATUS_URL =
            "http://customer-status-service/api/customers/{id}";
    
    private static final Logger log = LoggerFactory.getLogger(CustomerService.class);


    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

    public Optional<Customer> getCustomerById(Long id) {
        return customerRepository.findById(id);
    }

    public Customer createCustomer(Customer customer) {
        customer.setModificationDate(LocalDate.now());
        return customerRepository.save(customer);
    }

    public Customer updateCustomer(Long id, Customer customerDetails) {
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        
        log.info("Updating Customer Record for Customer Id {}", id);

        customer.setCustomerName(customerDetails.getCustomerName());
        customer.setCustomerDob(customerDetails.getCustomerDob());
        customer.setModifiedBy(customerDetails.getModifiedBy());
        customer.setModificationDate(LocalDate.now());

        return customerRepository.save(customer);
    }

    public void deleteCustomer(Long id) {
    	
    	log.info("Deleting Customer Record for Customer Id {}", id);
        customerRepository.deleteById(id);
    }

    // ---------------------------------------------------------
    // NEW METHOD: RETURN CUSTOMER + STATUS (DIRECT API CALL)
    // ---------------------------------------------------------
    public CustomerDetailsWithStatusResponse getCustomerDetailsWithStatus(Long id) {

        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        
        log.info("Before calling CustomerStatus API {}", id);

        // --- CALL CUSTOMER STATUS SERVICE ---
        CustomerStatusResponse statusResponse = restTemplate.getForObject(
                STATUS_URL,
                CustomerStatusResponse.class,
                id
        );

        String status = (statusResponse != null) ? statusResponse.getStatus() : "UNKNOWN";
        
        log.info("Received status from  CustomerStatus API {}", status);

//        String status="Active";
        // --- MAP TO DTO ---
        return CustomerMapper.mapToDto(customer, status);
    }
}
