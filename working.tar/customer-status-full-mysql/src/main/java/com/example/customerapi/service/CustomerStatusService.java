package com.example.customerapi.service;
import com.example.customerapi.dto.CustomerStatusResponse;
import com.example.customerapi.entity.CustomerStatus;
import com.example.customerapi.repository.CustomerStatusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CustomerStatusService {

    @Autowired
    private CustomerStatusRepository repository;

    /**
     * Returns the CustomerStatusResponse for the given customerId.
     * Throws RuntimeException if not found (controller converts to 404).
     */
    public CustomerStatusResponse getStatusByCustomerId(Long customerId) {
        Optional<CustomerStatus> opt = repository.findById(customerId);

        if (!opt.isPresent()) {
            throw new RuntimeException("Status not found for customerId: " + customerId);
        }

        CustomerStatus cs = opt.get();
        CustomerStatusResponse resp = new CustomerStatusResponse();
        resp.setCustomerId(cs.getCustomerId());
        resp.setStatus(cs.getStatus());
        return resp;
    }

    /**
     * Save or update status for a customer (useful later).
     */
    public CustomerStatus saveOrUpdateStatus(CustomerStatus customerStatus) {
        return repository.save(customerStatus);
    }
}
