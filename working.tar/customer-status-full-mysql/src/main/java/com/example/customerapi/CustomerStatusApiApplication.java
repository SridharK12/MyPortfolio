package com.example.customerapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerStatusApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(CustomerStatusApiApplication.class, args);
    }
}
